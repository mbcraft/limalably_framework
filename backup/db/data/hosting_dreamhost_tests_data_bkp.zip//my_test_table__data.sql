INSERT INTO my_test_table (id,value) VALUES (1,1);

INSERT INTO my_test_table (id,value) VALUES (2,2);

INSERT INTO my_test_table (id,value) VALUES (3,3);

