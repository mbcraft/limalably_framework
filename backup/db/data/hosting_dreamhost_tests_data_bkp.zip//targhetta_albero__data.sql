INSERT INTO targhetta_albero (id,codice_targhetta) VALUES (1,'abc1');

INSERT INTO targhetta_albero (id,codice_targhetta) VALUES (2,'abc2');

