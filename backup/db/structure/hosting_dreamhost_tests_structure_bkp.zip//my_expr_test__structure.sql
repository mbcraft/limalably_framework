CREATE TABLE `my_expr_test` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `my_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci

