CREATE TABLE `my_test` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `testo` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `valore_int` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci

