CREATE TABLE `my_test_table` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `value` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci

