CREATE TABLE `targhetta_albero` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `codice_targhetta` varchar(256) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci

