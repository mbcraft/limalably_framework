INSERT INTO my_expr_test (id,my_time) VALUES (1,'2022-11-09 08:54:31');

