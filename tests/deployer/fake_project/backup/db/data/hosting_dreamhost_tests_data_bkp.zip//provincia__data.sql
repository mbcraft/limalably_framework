INSERT INTO provincia (id,nome,codice,regione_id) VALUES (1,'ProvinciaA','P-A1',1);

INSERT INTO provincia (id,nome,codice,regione_id) VALUES (2,'ProvinciaB','P-B1',1);

