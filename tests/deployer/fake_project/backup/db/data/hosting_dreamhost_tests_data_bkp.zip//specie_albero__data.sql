INSERT INTO specie_albero (id,nome) VALUES (2742,'leccio');

