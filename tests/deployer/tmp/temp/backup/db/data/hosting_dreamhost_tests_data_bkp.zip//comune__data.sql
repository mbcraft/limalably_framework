INSERT INTO comune (id,nome,codice,provincia_id) VALUES (6,'COMUNE_TEST','CODICE_COMUNE_TEST',8);

