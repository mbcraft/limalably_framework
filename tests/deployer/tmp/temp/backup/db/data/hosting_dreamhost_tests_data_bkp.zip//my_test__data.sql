INSERT INTO my_test (id,testo,valore_int) VALUES (1,'abcd2z',123);

INSERT INTO my_test (id,testo,valore_int) VALUES (2,'abcd3z',345);

INSERT INTO my_test (id,testo,valore_int) VALUES (3,'abcd2',12);

INSERT INTO my_test (id,testo,valore_int) VALUES (4,'abcd2',12);

INSERT INTO my_test (id,testo,valore_int) VALUES (5,'abcd3',34);

