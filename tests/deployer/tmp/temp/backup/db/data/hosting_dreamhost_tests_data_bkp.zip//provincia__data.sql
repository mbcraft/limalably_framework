INSERT INTO provincia (id,nome,codice,regione_id) VALUES (8,'PROVINCIA_TEST','CODICE_PROVINCIA_TEST',9);

