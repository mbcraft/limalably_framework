INSERT INTO albero (id,data_piantumazione,latitudine,longitudine,specie_albero_id,comune_id) VALUES (1085,'2022-08-20',44.4106,12.0095,2742,6);

