INSERT INTO check_up_albero (id,albero_id,data,esito) VALUES (5320,1085,'2022-08-20',1);

INSERT INTO check_up_albero (id,albero_id,data,esito) VALUES (5321,1085,'2022-08-20',2);

INSERT INTO check_up_albero (id,albero_id,data,esito) VALUES (5322,1085,'2022-08-20',3);

INSERT INTO check_up_albero (id,albero_id,data,esito) VALUES (5323,1085,'2022-08-20',4);

INSERT INTO check_up_albero (id,albero_id,data,esito) VALUES (5324,1085,'2022-08-20',5);

