INSERT INTO regione (id,nome,codice) VALUES (1,'RegioneA','R-A1');

